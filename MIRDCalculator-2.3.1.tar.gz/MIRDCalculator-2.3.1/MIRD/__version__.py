#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Nov 17 15:26:24 2021

@author: alejandrobertolet
"""

VERSION = (2, 1, 0)

__version__ = '.'.join(map(str, VERSION))