#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Aug 4 14:03:31 2022
@author: alejandrobertolet
"""

from reportingRPT import *