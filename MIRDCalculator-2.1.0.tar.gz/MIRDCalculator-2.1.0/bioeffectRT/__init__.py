#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 2 08:36:20 2022
@author: alejandrobertolet
"""

from bioeffectRT import *
from MIRD import Svalues
from DICOM_RT import *